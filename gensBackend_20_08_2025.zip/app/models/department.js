const { DataTypes } = require("sequelize");
const sequelize = require("../connection/connection");
const Department = sequelize.define('department', {
    id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true
    },
    tenantId: {
        type: DataTypes.UUID,
        allowNull: false
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false
    },
    status: {
        type: DataTypes.ENUM('active', 'inactive'),
        defaultValue: 'active'
    },
    createdBy: {
        type: DataTypes.UUID,
        allowNull: true
    },
    updatedBy: {
        type: DataTypes.UUID,
        allowNull: true
    }
})


// Department.sync({ alter: true }).then(() => {
//     console.log('Department model synced successfully');
// }).catch((error) => {
//     console.error('Error syncing Department model:', error);
// });

module.exports = Department;